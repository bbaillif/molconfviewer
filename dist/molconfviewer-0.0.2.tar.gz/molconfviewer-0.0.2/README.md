# Mol Viewer

This is a simple package wrapping [py3dmol](https://github.com/avirshup/py3dmol) for a single command visualization of a RDKit molecule and its conformations (embed as Conformer objects in the Molecule)